Part 2 of 2. Nine foreground PNGs (FG01–FG09) and SK04. Open this ZIP on its own. Part 1 has the eight inner shells.
