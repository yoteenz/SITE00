Part 1 of 2. Eight inner shells (OV01–OV08). Open this ZIP on its own. Part 2 has the nine foregrounds and SK04.
