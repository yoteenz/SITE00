Full pipeline QA output (extract_layers.py --qa). Full-frame previews are JPEG q92; layer_*.png keep their real alpha. Rerunning the pipeline reproduces the originals exactly.
